﻿namespace Model.Entities;

public enum BuchStatus
{
    Keins,
    Favoriten,
    Lesen,
    Gelesen
}